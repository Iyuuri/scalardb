package sample;

import com.scalar.db.api.DistributedTransaction;
import com.scalar.db.api.DistributedTransactionManager;
import com.scalar.db.api.Get;
import com.scalar.db.api.Put;
import com.scalar.db.api.Result;
import com.scalar.db.exception.transaction.TransactionException;
import com.scalar.db.io.Key;
import com.scalar.db.service.TransactionFactory;
import java.io.IOException;
import java.util.Optional;

public class testWithTransaction extends test {

  private final DistributedTransactionManager manager;

  public testWithTransaction() throws IOException {
    TransactionFactory factory = new TransactionFactory(dbConfig);
    manager = factory.getTransactionManager();
    manager.with(NAMESPACE, TABLENAME);
  }

  @Override
  public void add(String id, String productname,String registration_date,int price,String address) throws TransactionException {
    // Start a transaction
    DistributedTransaction tx = manager.start();

    try {
      Get get = new Get(new Key(ID, id));
      Optional<Result> result = tx.get(get);
      if(result.isPresent()){
          System.out.println("this item is already selling.");
      }
      else{
        // registrate item
        Put put = new Put(new Key(ID, id)).withValue(PRODUCTNAME, productname).withValue(regidate, registration_date).withValue(PRICE, price).withValue(ADDRESS, address).withValue(ISSOLD,0);
        tx.put(put);
      }
      // Commit the transaction (records are automatically recovered in case of failure)
      tx.commit();
    } catch (Exception e) {
      tx.abort();
      throw e;
    }   
            
  }

  @Override
  public void sold(String id) throws TransactionException {
    // Start a transaction
    DistributedTransaction tx = manager.start();
    try {
      // Retrieve the current balances for ids
      Get Get = new Get(new Key(ID, id));
      Optional<Result> Result = tx.get(Get);
      // Update the issold
      if(Result.isPresent()){
        Put Put = new Put(new Key(ID, id)).withValue(ISSOLD, 1);
        tx.put(Put);
      }
      // Commit the transaction (records are automatically recovered in case of failure)
      tx.commit();
    } catch (Exception e) {
      tx.abort();
      throw e;
    }
  }
  @Override
  public int getinstance(String id) throws TransactionException {
    // Start a transaction
    DistributedTransaction tx = manager.start();

    try {
      // Retrieve
      Get get = new Get(new Key(ID, id));
      Optional<Result> result = tx.get(get);

      int sold = 0;
      if (result.isPresent()) {
          sold = result.get().getValue(ISSOLD).get().getAsInt();
        }

      // Commit the transaction
      tx.commit();

      return sold;
    } catch (Exception e) {
      tx.abort();
      throw e;
    }
  }
  @Override
  public void close() {
    manager.close();
  }
}
