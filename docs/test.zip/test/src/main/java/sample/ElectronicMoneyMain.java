package sample;

public class ElectronicMoneyMain {
  public static void main(String[] args) throws Exception {
    String mode = null;
    String action = null;
    int amount = 0;
    String to = null;
    String from = null;
    String id = null;

    for (int i = 0; i < args.length; ++i) {
      if ("-mode".equals(args[i])) {
        mode = args[++i];
      } else if ("-action".equals(args[i])) {
        action = args[++i];
      } else if ("-amount".equals(args[i])) {
        amount = Integer.parseInt(args[++i]);
      } else if ("-to".equals(args[i])) {
        to = args[++i];
      } else if ("-from".equals(args[i])) {
        from = args[++i];
      } else if ("-id".equals(args[i])){
        id = args[++i];
      } else if ("-help".equals(args[i])) {
        printUsageAndExit();
      }
    }
    if (action == null) {
      printUsageAndExit();
    }

    ElectronicMoney eMoney = null;
    if (mode.equalsIgnoreCase("storage")) {
      eMoney = new ElectronicMoneyWithStorage();
    } else {
      eMoney = new ElectronicMoneyWithTransaction();
    }

    if (action.equalsIgnoreCase("charge")) {
      eMoney.charge(to, amount);
    } else if (action.equalsIgnoreCase("pay")) {
      if (from == null) {
        printUsageAndExit();
      }
      eMoney.pay(from, to, amount);
    } else if (action.equalsIgnoreCase("getBalance")){       
      if (id == null){
        printUsageAndExit();
        return;
      }
      int balance = eMoney.getBalance(id);
      System.out.println("The balance for " + id + " is " + balance);
    }
    eMoney.close();
  }

  private static void printUsageAndExit() {
    System.err.println(
        "ElectronicMoneyMain -mode storage/transaction -action charge/pay -amount number -to id [-from id (needed for pay)]");
    System.exit(1);
  }
}
